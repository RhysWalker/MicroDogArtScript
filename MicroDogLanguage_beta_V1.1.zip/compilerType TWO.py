import time

print("Please type the name of the file you wish to compile")
print("The file must be in this director")
fileName = input("-->")

def execute(fileName):
    f = open(fileName+".txt", "r+")
    code = f.read()
    f.close()
    print("Please give the file you want to create a name")
    fileName = input("-->")
    f = open(fileName+".py", "w")
    print(code)
    code = code.split("\n")
    length = len(code)
    f.write("from turtle import Turtle, Screen\n")
    f.write("import time\n")
    f.write("turtle = Turtle()\n")
    f.write("screen = Screen()\n")
    for x in range(0, length):
        point = code[x].split(" ")
        if point[0] == "f":
            f.write("turtle.forward(" + str(point[1]) +")\n")
        if point[0] == "b":
            f.write("turtle.backward(" + str(point[1]) + ")\n")
        if point[0] == "r":
            f.write("turtle.right(" + str(point[1]) + ")\n")
        if point[0] == "l":
            f.write("turtle.left(" + str(point[1]) + ")\n")
        if point[0] == "g":
            f.write("turtle.goto(" + str(point[1]) + "," + str(point[2]) + ")\n")
        if point[0] == "p-up":
            f.write("turtle.penup()\n")
        if point[0] == "p-down":
            f.write("turtle.pendown()\n")
        if point[0] == "s-size":
            f.write("screen.screensize(" + str(point[1]) + "," + str(point[2]) + ")\n")
        if point[0] == "set-x":
            f.write("turtle.setx(" + str(point[1]) + ")\n")
        if point[0] == "set-y":
            f.write("turtle.sety(" + str(point[1]) + ")\n")
    f.write("time.sleep(2)")
    print("FILE HAS BEEN CONVERTED DOUBLE CLICK THE PYTHON FILE TO RUN")
    time.sleep(2)
execute(fileName)
