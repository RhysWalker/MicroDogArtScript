from turtle import Screen, Turtle
import time

print("Please type the file you wish to compile and run")
print("It must me placed in this directory")
fileName = input("-->")

def execute(fileName):
    turtle = Turtle()
    screen = Screen()
    f = open(fileName +".txt", "r+")
    code = f.read()
    print(code)
    code = code.split("\n")
    length = len(code)
    for x in range(0, length):
        point = code[x].split(" ")
        if point[0] == "f":
            turtle.forward(int(point[1]))
        if point[0] == "b":
            turtle.backward(int(point[1]))
        if point[0] == "r":
            turtle.right(int(point[1]))
        if point[0] == "l":
            turtle.left(int(point[1]))
        if point[0] == "g":
            turtle.goto(int(point[1]), int(point[2]))
        if point[0] == "p-up":
            turtle.penup()
        if point[0] == "p-down":
            turtle.pendown()
        if point[0] == "s-size":
            screen.screensize(int(point[1]), int(point[2]))
        if point[0] == "set-x":
            turtle.setx(int(point[1]))
        if point[0] == "set-y":
            turtle.sety(int(point[1]))
            


    screen.mainloop()

execute(fileName)
